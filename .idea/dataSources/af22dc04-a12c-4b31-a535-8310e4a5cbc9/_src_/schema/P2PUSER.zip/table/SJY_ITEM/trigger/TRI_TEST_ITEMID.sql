create trigger TRI_TEST_ITEMID
	before insert
	on SJY_ITEM
	for each row
declare
  nextid number;
begin
  IF :new.id IS NULL or :new.id=0 THEN --DepartId是列名
    select S_SI_Item.nextval --S_S_DEPART正是刚才创建的
    into nextid
    from sys.dual;
    :new.id:=nextid;
  end if;
end tri_test_itemId;
