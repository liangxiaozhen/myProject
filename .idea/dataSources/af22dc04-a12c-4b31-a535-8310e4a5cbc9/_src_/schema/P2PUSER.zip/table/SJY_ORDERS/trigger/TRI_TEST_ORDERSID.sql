create trigger TRI_TEST_ORDERSID
	before insert
	on SJY_ORDERS
	for each row
declare
  nextid number;
begin
  IF :new.id IS NULL or :new.id=0 THEN --id是列名
    select Seq_test_Orders.nextval --Seq_test_Orders正是刚才创建的
    into nextid
    from sys.dual;
    :new.id:=nextid;
  end if;
end tri_test_ordersId;
