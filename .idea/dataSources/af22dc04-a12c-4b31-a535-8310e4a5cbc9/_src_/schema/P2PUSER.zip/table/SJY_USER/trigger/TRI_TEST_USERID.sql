create trigger TRI_TEST_USERID
	before insert
	on SJY_USER
	for each row
declare
  nextid number;
begin
  IF :new.id IS NULL or :new.id=0 THEN --id是列名
    select Seq_test_user.nextval --S_S_DEPART正是刚才创建的
    into nextid
    from sys.dual;
    :new.id:=nextid;
  end if;
end tri_test_userId;
